# credits = Simran

import pygame
import random
import os

pygame.mixer.init()
pygame.init()

# Colors
white = (255,255,255)
red = (255,0,0)
black = (0,0,0)
l_pink = (233,220,229)
lime = (0,255,0)
green = (0,128,0)
yellow = (255,255,0)

# Creating Window
screen_width = 900
screen_height = 600

game_window = pygame.display.set_mode((screen_width,screen_height))

# Background Image
bg = pygame.image.load("bg2.jpg")
bg = pygame.transform.scale(bg,(screen_width,screen_height)).convert_alpha()
bg1 = pygame.image.load("over.png")
bg1 = pygame.transform.scale(bg1,(screen_width,screen_height)).convert_alpha()
bg2 = pygame.image.load("edit.jpg")
bg2 = pygame.transform.scale(bg2,(screen_width,screen_height)).convert_alpha()

pygame.display.set_caption("Snakes with Simran")
pygame.display.update()

# GAme variables

clock = pygame.time.Clock()
font = pygame.font.SysFont('Harrington', 35)

def text_screen(text,color,x,y):
    screen_text = font.render(text,True,color)
    game_window.blit(screen_text,[x,y])

def plot_snake(game_window,color,snk_list,snake_size):
    for x,y in snk_list:
        pygame.draw.rect(game_window,color, [x, y, snake_size, snake_size])

def welcome():
    exit_game = False
    while not exit_game:
        game_window.fill((238,130,238))
        game_window.blit(bg2,(0,0))
        # text_screen("Welcome to snakes",black,300,270)
        # text_screen("/Press Space key to play",black,280,320)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit_game = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    pygame.mixer.music.load("wc.mp3")
                    pygame.mixer.music.play()

                    game_loop()

        pygame.display.update()
        clock.tick(60)
# Game Loop

def game_loop():
    exit_game = False
    game_over = False
    snake_x = 45
    snake_y = 55
    snake_size = 10
    fps = 28
    init_vel = 5
    init_vel2 = 6
    vel_x = 0
    vel_y = 0
    food_x = random.randint(0, screen_width / 2)
    food_y = random.randint(0, screen_height / 2)
    score = 0

    if (not os.path.exists("hiscore.txt")):
        with open("hiscore.txt","w") as f:
            f.write("0")
    with open("hiscore.txt", "r") as f:
        hiscore = f.read()

    snk_list = []
    snk_length = 1
    while not exit_game:
        if game_over:

            with open("hiscore.txt", "w") as f:
                f.write(str(hiscore))
            game_window.fill(white)
            game_window.blit(bg1, (0,0))

            # text_screen("Game over!!",red,370,250)
            # text_screen("Press Enter to continue ",red,310,350)
            text_screen(f"Score: {score}",lime,355,430)
            text_screen(f"Hiscore: {hiscore}",lime,355,470)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit_game = True
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        welcome()

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        game_loop()

        else:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit_game = True

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RIGHT:
                        vel_x = init_vel
                        vel_y = 0
                    elif event.key == pygame.K_LEFT:
                        vel_x = -init_vel
                        vel_y = 0
                    elif event.key == pygame.K_UP:
                        vel_y = -init_vel
                        vel_x = 0
                    elif event.key == pygame.K_DOWN:
                        vel_y = init_vel
                        vel_x = 0
                    elif event.key == pygame.K_q:
                        score += 10
                    elif event.key == pygame.K_b:
                        init_vel -= 0.5
                    elif event.key == pygame.K_s:
                        init_vel += 1



            snake_x = snake_x+vel_x
            snake_y = snake_y+vel_y

            if abs(snake_x - food_x)<6 and abs(snake_y - food_y)<6:
                score += 10


                food_x = random.randint(0, screen_width / 2)
                food_y = random.randint(0, screen_height / 2)
                snk_length += 5
                if score>int(hiscore):
                    hiscore=score

            game_window.fill(l_pink)
            game_window.blit(bg,(0,0))
            text_screen("Score" + str(score), white, 5, 5)
            text_screen("Hiscore:" + str(hiscore), white, 5, 30)
            pygame.draw.rect(game_window, red, [food_x, food_y, snake_size, snake_size])

            head = []
            head.append(snake_x)
            head.append(snake_y)
            snk_list.append(head)

            if len(snk_list)>snk_length:
                del snk_list[0]

            if head in snk_list[:-1]:
                game_over = True

            if snake_x < 0 or snake_x > screen_width or snake_y < 0 or snake_y > screen_height:
                game_over = True
                pygame.mixer.music.load("09 mb game over.mp3")
                pygame.mixer.music.play()

            plot_snake(game_window,black,snk_list,snake_size)
        pygame.display.update()
        clock.tick(fps)

    pygame.quit()
    quit()

welcome()
game_loop()
